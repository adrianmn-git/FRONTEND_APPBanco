'use client'

import { useEffect, useState } from "react";
import { HttpClient } from "@/libs/HttpClient";
import { Button } from "@mui/material";
import TextField from '@mui/material/TextField';
import React, { } from "react";
import { useRouter } from "next/navigation";
import { TokenManager } from "@/libs/TokenManager";

export default function Home() {

  const [formData, setFormData] = useState<{
    id: string,
    email: string,
    name: string,
    password: string,
  }>({
    id: '',
    email: '',
    name: '',
    password: '',
  })

  const router = useRouter()
  console.log(router)

  async function register(id: string, email: string, name: string, password: string) {
    const response = await HttpClient(
      `http://192.168.51.150:5004/api/register/${id}`,
      'POST',
      JSON.stringify({
        email,
        name,
        password
      })
    );

    if (response.status === 200) {
      alert("¡USUARI FET!")
    }
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault()
    await register(formData.id, formData.email, formData.name, formData.password)
    router.push('/login_page')
  }

  useEffect(() => {
    const token = TokenManager.get()
    if (token) router.push('/home_page')
  }, [])

  return (
    <div className="items-center justify-items-center p-8 pt-16 pb-20 gap-16 sm:p-20 font-[family-name:var(--font-geist-sans)]">
      <h1 className="text-5xl mx-16 mb-24 font-bold">REGISTRE BANC API</h1>
      <main className="flex flex-col gap-4 row-start-2 items-center sm:items-start">
        <form onSubmit={onSubmit}>
          <TextField type="number" value={formData.id} sx={{ minWidth: 300 }} label="ID" color="info" onChange={(e) => setFormData({ ...formData, id: e.target.value })} />
          <TextField type="text" value={formData.email} sx={{ minWidth: 300 }} label="Email" color="info" onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
          <TextField type="text" value={formData.name} sx={{ minWidth: 300 }} label="Name" color="info" onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
          <TextField type="password" value={formData.password} sx={{ minWidth: 300 }} label="Password" color="info" onChange={(e) => setFormData({ ...formData, password: e.target.value })} />
          <Button type="submit" sx={{ backgroundColor: 'black', color: 'white' }} fullWidth> Register </Button>
        </form>
      </main>
    </div>
  );
}
