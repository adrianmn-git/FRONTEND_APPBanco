'use client'

import { useEffect, useState } from "react";
import { HttpClient } from "@/libs/HttpClient";
import { Button } from "@mui/material";
import TextField from '@mui/material/TextField';
import React, { } from "react";
import { useRouter } from "next/navigation";
import { TokenManager } from "@/libs/TokenManager";
import Divider from '@mui/material/Divider';
import Chip from '@mui/material/Chip';

export default function Home() {

  const router = useRouter()

  useEffect(() => {
    const token = TokenManager.get()
    if (!token) router.push('/login_page')
  }, [])

  async function postBankAccount(e: React.FormEvent) {
      e.preventDefault()
      router.push('/bankaccountpost_page')
    }

  return (
    <div className="items-center justify-items-center p-8 pt-16 pb-20 gap-16 sm:p-20 font-[family-name:var(--font-geist-sans)]">
      <h1 className="text-5xl mx-16 mb-24 font-bold">HOME BANC API</h1>
      <main className="flex flex-col w-[1000px] gap-8 row-start-2 items-center sm:items-start">
        <Divider><Chip label="Afegir" size="medium" /></Divider>
        <Button sx={{ fontWeight: 700, backgroundColor: 'black', color: 'white', borderRadius: 25 }} onClick={postBankAccount} fullWidth> Compte </Button>
        <Divider><Chip label="Comptes" size="medium" /></Divider>
      </main>
    </div>
  );
}
