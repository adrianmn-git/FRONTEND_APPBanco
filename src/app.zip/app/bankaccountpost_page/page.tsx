'use client'

import { useEffect, useState } from "react";
import { HttpClient } from "@/libs/HttpClient";
import { Button } from "@mui/material";
import TextField from '@mui/material/TextField';
import React, { } from "react";
import { useRouter } from "next/navigation";
import { TokenManager } from "@/libs/TokenManager";
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';

export default function Home() {

    const [formData, setFormData] = useState<{
        id: string,
        userId: string,
        currencyId: string,
        type: string,
    }>({
        id: '',
        userId: '',
        currencyId: '',
        type: '',
    })

    const router = useRouter()

    async function postbankaccount(id: string, userId: string, currencyId: string, type: string) {
        const response = await HttpClient(
            `http://192.168.51.150:5004/api/bank-accounts/${id}/${userId}`,
            'POST',
            JSON.stringify({
                currencyId,
                type
            })
        );

        if (response.status === 200) {
            alert("COMPTE FET!")
        }
    }

    useEffect(() => {
        const token = TokenManager.get()
        if (!token) router.push('/login_page')
    }, [])

    async function onSubmit(e: React.FormEvent) {
        e.preventDefault()
        await postbankaccount(formData.id, formData.userId, formData.currencyId, formData.type)
        router.push('/home_page')
    }

    console.log(formData.type)

    return (
        <div className="items-center justify-items-center p-8 pt-16 pb-20 gap-16 sm:p-20 font-[family-name:var(--font-geist-sans)]">
            <h1 className="text-5xl mx-16 mb-24 font-bold">POST BANK ACCOUNT</h1>
            <main className="flex flex-col gap-4 row-start-2 items-center sm:items-start">
                <form onSubmit={onSubmit}>
                    <TextField type="number" value={formData.id} sx={{ minWidth: 300 }} label="ID" color="info" onChange={(e) => setFormData({ ...formData, id: e.target.value })} />
                    <TextField type="number" value={formData.userId} sx={{ minWidth: 300 }} label="User ID" color="info" onChange={(e) => setFormData({ ...formData, userId: e.target.value })} />
                    <TextField type="number" value={formData.currencyId} sx={{ minWidth: 300 }} label="Currency ID" color="info" onChange={(e) => setFormData({ ...formData, currencyId: e.target.value })} />
                    <Select value={formData.type} sx={{ minWidth: 200 }} label="Type" color="info" onChange={(e) => setFormData({ ...formData, type: e.target.value })}>
                        <MenuItem value={"NORMAL"}>NORMAL</MenuItem>
                        <MenuItem value={"SAVINGS"}>SAVINGS</MenuItem>
                    </Select>
                    <Button type="submit" sx={{ backgroundColor: 'black', color: 'white' }} fullWidth> Create Bank Account </Button>
                </form>
            </main>
        </div>
    );
}
