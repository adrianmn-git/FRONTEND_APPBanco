'use client'

import { useEffect, useState } from "react";
import { HttpClient } from "@/libs/HttpClient";
import { TokenManager } from "@/libs/TokenManager";
import { Button } from "@mui/material";
import TextField from '@mui/material/TextField';
import React, { } from "react";
import { useRouter } from "next/navigation";

export default function Home() {

    const [formData, setFormData] = useState<{
        email: string,
        password: string,
    }>({
        email: '',
        password: ''
    })

    const router = useRouter()

    async function login(email: string, password: string) {
        const response = await HttpClient(
            'http://192.168.51.150:5004/api/login',
            'POST',
            JSON.stringify({
                email,
                password
            })
        );

        if (response.status === 200) {
            const r = await response.json();
            TokenManager.set(r.token);
        }
    }

    async function onSubmit(e: React.FormEvent) {
        e.preventDefault()
        await login(formData.email, formData.password)
        router.push('/home_page')
    }


    return (
        <div className="items-center justify-items-center p-8 pt-16 pb-20 gap-16 sm:p-20 font-[family-name:var(--font-geist-sans)]">
            <h1 className="text-5xl mx-16 mb-24 font-bold">LOGIN BANC API</h1>
            <main className="flex flex-col gap-4 row-start-2 items-center sm:items-start">
                <form onSubmit={onSubmit}>
                    <TextField type="text" value={formData.email} sx={{ minWidth: 300 }} label="Email" color="info" onChange={(e) => setFormData({...formData, email: e.target.value})} />
                    <TextField type="password" value={formData.password} sx={{ minWidth: 300 }} label="Password" color="info" onChange={(e) => setFormData({...formData, password: e.target.value})} />
                    <Button type="submit" sx={{ backgroundColor: 'black', color: 'white' }} fullWidth> Login </Button>
                </form>
            </main>
        </div>
    );
}
